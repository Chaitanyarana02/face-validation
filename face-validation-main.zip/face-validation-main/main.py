from flask import Flask, jsonify, request
import cv2
import face_recognition


app = Flask(__name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS



@app.route('/')
def test_app():
    return jsonify({'App is running - use face-validation route for validating faces'})


@app.route('/face-validation', methods=["POST"])
def face_validation():

    image_paths = request.files.getlist("file")

    if len(image_paths) > 4 :
        return jsonify({'error': 'Exceeded maximum number of files allowed'})

    encoded_faces = []

    ########### Checking to avoid Group photo #############
    for path in image_paths:
        if path and allowed_file(path.filename):
            image = face_recognition.load_image_file(path)
            face_encodings = face_recognition.face_encodings(image)
            if len(face_encodings) == 1: # Total Faces per images should be 1
                encoded_faces.append(face_encodings[0])
            else:
                print(f"Skipping {path} as it does not contain exactly one face.")
        else:
            print(f"Skipping {path} as it does not an image file.")
    if len(encoded_faces) < 2:
        return jsonify({'isValid': False})


    reference_face = encoded_faces[0]

    for encoding in encoded_faces[1:]:
        ## compare faces
        matches = face_recognition.compare_faces([reference_face], encoding)

    if not all(matches):
        return jsonify({'isValid': False})
    else :
        return jsonify({'isValid': True})

if __name__ == '__main__':
    app.run()