
## To Run the Code

Create Virtual enviornment 

```
  Virtualenv venv
```

active enviornment -  
path to active : venv/bin

```
  source active
```

Install packages

```
  pip install -r requirements.txt
```

Run the code

```
  Python main.py
```
